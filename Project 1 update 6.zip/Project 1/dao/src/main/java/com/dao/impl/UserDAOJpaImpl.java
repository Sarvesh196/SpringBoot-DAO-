package com.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dao.entity.User;
import com.dao.interfaces.UserDAO;

import jakarta.persistence.EntityManager;

import jakarta.transaction.Transactional;

/**
 * UserDAOJpaImpl class implements the UserDAO interface for data access operations related to User entity.
 * This class uses JPA EntityManager for database operations.
 * It provides methods for saving, finding, updating, and deleting user records.
 *
 * @see UserDAO
 */
@Repository
public class UserDAOJpaImpl implements UserDAO{

    // Injecting the EntityManager to perform database operations
	@Autowired
    private EntityManager entityManager;

	@Override
    @Transactional
    public User save(User user) {
        entityManager.persist(user);
        return user;
    }

    @Override
    public User findById(int id) {
        return entityManager.find(User.class, id);
    }

    @Override
    public List<User> findAll() {
        return entityManager.createQuery("FROM User", User.class).getResultList();
    }

    @Override
    @Transactional
    public User update(User user) {
        return entityManager.merge(user);
    }

    @Override
    @Transactional
    public void deleteById(int id) {
        User user = entityManager.find(User.class, id);
        if (user != null) {
            entityManager.remove(user);
        }
    }
}