package com.dao;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Main application class for the Spring Boot application.
 * This class contains the main method to run the application.
 * It is annotated with @SpringBootApplication, which enables auto-configuration,
 * component scanning, and JPA repositories.
 * The application scans for components in the "com.dao" package and its sub-packages.
 * It also scans for entity classes in the "com.dao.entity" package
 * and JPA repositories in the "com.dao.repo" package.
 **/

@SpringBootApplication
@ComponentScan(basePackages = "com.dao")
@EntityScan(basePackages = "com.dao.entity")
@EnableJpaRepositories(basePackages = "com.dao.repo")

public class Application {
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}

