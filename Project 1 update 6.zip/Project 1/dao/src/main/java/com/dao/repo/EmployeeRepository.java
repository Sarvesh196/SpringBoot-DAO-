package com.dao.repo;
 
import org.springframework.stereotype.Repository;
 
import com.dao.entity.Employee;

/**
 * EmployeeRepository interface for CRUD operations on Employee entity.
 * This interface extends BaseRepository to inherit basic CRUD functionality.
 * It is annotated with @Repository to indicate that it is a Spring Data repository.
 *
 * @param <Employee> the entity type
 * @param <Integer> the type of the entity's identifier
 */
@Repository
public interface EmployeeRepository extends BaseRepository<Employee, Integer> {
	
}
 
 
