package com.dao.impl;


import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dao.entity.Employee;
import com.dao.interfaces.EmployeeDAO;

/**
 * EmployeeDAOJpaImpl class implements the EmployeeDAO interface for data access operations related to Employee entity.
 * This class uses JPA EntityManager for database operations.
 * It provides methods for saving, finding, updating, and deleting employee records.
 *
 * @see EmployeeDAO
 */
@Repository
public class EmployeeDAOJpaImpl implements EmployeeDAO{

	@Autowired
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public Employee save(Employee employee) {
        entityManager.persist(employee);
        return employee;
    }
	
	@Override
    public Employee findbyempid(int empid) {
        return entityManager.find(Employee.class, empid);
    }
	
	@Override
    public List<Employee> findAll() {
        return entityManager.createQuery("FROM Employee", Employee.class).getResultList();
    }
	
	
    @Override
    @Transactional
    public Employee update(Employee employee) {
        return entityManager.merge(employee);
    }

    @Override
    @Transactional
    public void deleteByempid(int empid) {
        Employee employee = entityManager.find(Employee.class, empid);
        if (employee != null) {
            entityManager.remove(employee);
        }
    }
}
