package com.dao.controller;


import com.dao.entity.User;
import com.dao.service.UserService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * EmployeeController class for handling HTTP requests related to Employee entity.
 * This class provides endpoints for creating, retrieving, updating, and deleting employee records.
 * It uses EmployeeService to perform the actual business logic.
 **/

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    /**
     * Endpoint to create a new employee.
     * @param employee The employee object to be created.
     * @return ResponseEntity with the created employee and HTTP status 201 (Created).
     */
    @PostMapping
    public ResponseEntity<User> createUser(@Valid @RequestBody User user) {
        User savedUser = userService.saveUser(user);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }
    
    /**
     * Endpoint to retrieve an employee by ID.
     * @param id The ID of the employee to be retrieved.
     * @return ResponseEntity with the employee object and HTTP status 200 (OK) if found, or 404 (Not Found) if not found.
     */

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable int id) {
        User user = userService.getUserById(id);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.status(HttpStatus.NOT_FOUND).body("User doesn't exist with ID " + id);
    }

    /**
     * Endpoint to retrieve all employees.
     * @return ResponseEntity with a list of all employees and HTTP status 200 (OK).
     */
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }
    
    
    /**
     * Endpoint to update an existing employee.
     * @param id The ID of the employee to be updated.
     * @param employee The employee object with updated fields.
     * @return ResponseEntity with the updated employee and HTTP status 200 (OK) if found, or 404 (Not Found) if not found.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable int id, @RequestBody User user) {
        User existingUser = userService.getUserById(id);
        
        if (existingUser == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User doesn't exist with ID " + id);
        }
        // Merge fields: If new field is null or empty, keep the existing value
        if (user.getUsername() != null && !user.getUsername().isBlank()) {
            existingUser.setUsername(user.getUsername());
        }
        if (user.getEmail() != null && !user.getEmail().isBlank()) {
            existingUser.setEmail(user.getEmail());
        }
        if (user.getPassword() != null && !user.getPassword().isBlank()) {
            existingUser.setPassword(user.getPassword());
        }
        // Save the updated entity
        User updatedUser = userService.updateUser(existingUser);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Endpoint to delete an employee by ID.
     * @param id The ID of the employee to be deleted.
     * @return ResponseEntity with a success message and HTTP status 200 (OK).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable int id) {
        userService.deleteUser(id);
        return ResponseEntity.ok("User Deleted Successfully");
    }
}