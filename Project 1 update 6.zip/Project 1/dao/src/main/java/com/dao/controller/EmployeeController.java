package com.dao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.entity.Employee;
import com.dao.service.EmployeeService;

import jakarta.validation.Valid;

/**
 * EmployeeController class for handling HTTP requests related to Employee entity.
 * This class provides endpoints for creating, retrieving, updating, and deleting employee records.
 * It uses EmployeeService to perform the actual business logic.
 **/
@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    /**
     * Endpoint to create a new employee.
     * @param employee The employee object to be created.
     * @return ResponseEntity with the created employee and HTTP status 201 (Created).
     */
    @PostMapping
    public ResponseEntity<Employee> createEmployee(@Valid @RequestBody Employee employee) {
        Employee savedEmployee = employeeService.saveEmployee(employee);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
    }

    /**
     * Endpoint to retrieve an employee by ID.
     * @param id The ID of the employee to be retrieved.
     * @return ResponseEntity with the employee object and HTTP status 200 (OK) if found, or 404 (Not Found) if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getEmployeeById(@PathVariable int id) {
    	Employee employee = employeeService.getEmployeeById(id);
        return employee != null ? ResponseEntity.ok(employee) : ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee doesn't exist with ID " + id);
    	
    }

    /**
     * Endpoint to retrieve all employees.
     * @return ResponseEntity with a list of all employees and HTTP status 200 (OK).
     */
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    /**
     * Endpoint to update an existing employee.
     * @param id The ID of the employee to be updated.
     * @param employee The employee object with updated fields.
     * @return ResponseEntity with the updated employee and HTTP status 200 (OK) if found, or 404 (Not Found) if not found.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateEmployee(@PathVariable int id, @RequestBody Employee employee) {
        Employee existingEmployee = employeeService.getEmployeeById(id);
        
        if (existingEmployee == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee doesn't exist with ID " + id);
        }
        // Merge fields: If new field is null or empty, keep the existing value
        if (employee.getName() != null && !employee.getName().isBlank()) {
            existingEmployee.setName(employee.getName());
        }
        if (employee.getEmail() != null && !employee.getEmail().isBlank()) {
            existingEmployee.setEmail(employee.getEmail());
        }
        if (employee.getPhno() != null && !employee.getPhno().isBlank()) {
            existingEmployee.setPhno(employee.getPhno());
        }
        // Save the updated entity
        Employee updatedEmployee = employeeService.updateEmployee(existingEmployee);
        return ResponseEntity.ok(updatedEmployee);
    }

    /**
     * Endpoint to delete an employee by ID.
     * @param id The ID of the employee to be deleted.
     * @return ResponseEntity with a success message and HTTP status 200 (OK).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable int id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.ok("Employee Deleted Successfully");
    }
}



