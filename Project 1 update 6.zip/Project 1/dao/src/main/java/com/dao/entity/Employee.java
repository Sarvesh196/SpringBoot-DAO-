package com.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;


/**
 * Employee entity class representing the employee details.
 * This class is mapped to the "employee_details" table in the database.
 * It contains fields for employee ID, name, email, and phone number.
 * The class includes validation annotations to ensure that certain fields are not blank.
**/

@Entity
@Table(name = "employee_details")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)               //empid is being auto-generated
	@Column(name = "id")
	private int empid;
	
	@Column(name = "Employee_Name")
	@NotBlank(message = "Employee name cannot be empty")
	private String name;
	
	
	@Column(name = "email")
	@NotBlank(message = "Email cannot be empty")
	private String email;
	
	
	@Column(name = "phno")
	@NotBlank(message = "Phone number cannot be empty")
	private String phno;
	
	public Employee() {}
	
	public Employee(int empid, String name, String email, String phno) {
		super();
		this.empid = empid;
		this.name = name;
		this.email = email;
		this.phno = phno;
	}
	
	// Getters and Setters
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = (name != null) ? name.trim() : null;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = (email != null) ? email.trim() : null;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = (phno != null) ? phno.trim() : null;
	}
	@Override
	public String toString() {
		return "employee [empid=" + empid + ", name=" + name + ", email=" + email + ", phno=" + phno + "]";
	}

}
