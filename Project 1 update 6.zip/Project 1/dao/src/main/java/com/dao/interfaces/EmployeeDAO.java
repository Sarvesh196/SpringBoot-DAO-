package com.dao.interfaces;

import java.util.List;

import com.dao.entity.Employee;

/**
 * EmployeeDAO interface for data access operations related to Employee entity.
 * This interface defines methods for saving, finding, updating, and deleting employee records.
 * It serves as a Data Access Object (DAO) for the Employee entity.
 **/

public interface EmployeeDAO {
	
	Employee save(Employee employee);
	Employee findbyempid(int empid);
	List<Employee> findAll();
	Employee update (Employee employee);
	void deleteByempid(int empid);
}