package com.dao.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * GlobalExceptionHandler class for handling exceptions globally in the application.
 * This class uses @RestControllerAdvice to handle exceptions thrown by controllers.
 * It provides a method to handle MethodArgumentNotValidException and return a custom error response.
 **/

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationException(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.put(error.getField(), error.getDefaultMessage());
        }
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
	
	
//	@ExceptionHandler(MethodArgumentNotValidException.class)
//	    public ResponseEntity<Map<String, String>> handleValidationException(MethodArgumentNotValidException ex) {
//	        Map<String, String> errors = new HashMap<>();
//	        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
//	            errors.put(ex.getMessage(),ex.getStackTrace().toString());
//	        }
//	        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
//	    }
}