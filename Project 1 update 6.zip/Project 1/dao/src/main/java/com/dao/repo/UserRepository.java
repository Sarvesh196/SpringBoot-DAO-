package com.dao.repo;
 
import org.springframework.stereotype.Repository;
 
import com.dao.entity.User;

/**
 * UserRepository interface for CRUD operations on User entity.
 * This interface extends BaseRepository to inherit basic CRUD functionality.
 * It is annotated with @Repository to indicate that it is a Spring Data repository.
 *
 * @param <User> the entity type
 * @param <Integer> the type of the entity's identifier
 */
@Repository
public interface UserRepository extends BaseRepository<User, Integer>{
	
}