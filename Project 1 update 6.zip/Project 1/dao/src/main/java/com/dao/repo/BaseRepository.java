package com.dao.repo;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * BaseRepository interface for generic CRUD operations.
 * This interface extends JpaRepository to provide basic CRUD functionality.
 * It is marked with @NoRepositoryBean to indicate that it should not be instantiated directly.
 *
 * @param <T> the entity type
 * @param <ID> the type of the entity's identifier
 */
@NoRepositoryBean
public interface BaseRepository<T, ID> extends JpaRepository<T, ID>{
	
}