package com.dao.interfaces;

import java.util.List;

import com.dao.entity.User;

/**
 * UserDAO interface for data access operations related to User entity.
 * This interface defines methods for saving, finding, updating, and deleting user records.
 * It serves as a Data Access Object (DAO) for the User entity.
 **/

public interface UserDAO {
    User save(User user);
    User findById(int id); 
    List<User> findAll(); 
    User update(User user); 
    void deleteById(int id); 
}