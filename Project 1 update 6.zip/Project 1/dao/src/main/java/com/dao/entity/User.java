package com.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

/**
 * User entity class representing the user details.
 * This class is mapped to the "Users" table in the database.
 * It contains fields for user ID, username, password, and email.
 * The class includes validation annotations to ensure that certain fields are not blank.
 **/

@Entity
@Table(name = "Users")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "User_id")
	private int userid;
	
	@Column(name = "Username")
	@NotBlank(message = "Username cannot be empty")
	private String username;
	
	@Column(name = "Password")
	@NotBlank(message = "Password cannot be empty")
	private String password;
	
	@Column(name = "Email",nullable=false)
	@NotBlank(message = "Email cannot be empty")
	private String email;
	
	
	public User(int userid, String username, String password, String email) {
		super();
		this.userid = userid;
		this.username = username;
		this.password = password;
		this.email = email;
	}
	
	
	public User() {
		
	}

	// Getters and Setters

	public int getUserid() {
		return userid;
	}


	public void setUserid(int userid) {
		this.userid = userid;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = (username != null) ? username.trim() : null;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = (password != null) ? password.trim() : null;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = (email != null) ? email.trim() : null;
	}


	@Override
	public String toString() {
		return "user [userid=" + userid + ", username=" + username + ", password=" + password + ", email=" + email
				+ "]";
	}
}
