package com.dao.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.entity.Employee;
import com.dao.repo.EmployeeRepository;

/**
 * EmployeeService class for handling business logic related to Employee entity.
 * This class interacts with the EmployeeRepository to perform CRUD operations.
 * It provides methods to save, find, update, and delete employee records.
 **/

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee getEmployeeById(int empid) {
        return employeeRepository.findById(empid).orElse(null);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }    // Fetch all employees

    public Employee updateEmployee(Employee employee) {
        return employeeRepository.save(employee); // Save method acts as both insert & update
    }

    public void deleteEmployee(int empid) {
        employeeRepository.deleteById(empid);      // Delete method to remove employee by empid
    }
}

