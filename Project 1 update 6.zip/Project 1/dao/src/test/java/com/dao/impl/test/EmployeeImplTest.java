package com.dao.impl.test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dao.entity.Employee;
import com.dao.impl.EmployeeDAOJpaImpl;

public class EmployeeImplTest {

    @Mock
    private EntityManager entityManager;

    @InjectMocks
    private EmployeeDAOJpaImpl employeeDAO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveEmployee() {
        // Arrange
        Employee employee = new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890");

        // Act
        employeeDAO.save(employee);

        // Assert
        verify(entityManager, times(1)).persist(employee);
    }

    @Test
    void testFindByEmpId_Found() {
        // Arrange
        Employee employee = new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890");
        when(entityManager.find(Employee.class, 1)).thenReturn(employee);

        // Act
        Employee foundEmployee = employeeDAO.findbyempid(1);

        // Assert
        assertNotNull(foundEmployee);
        assertEquals("Sarvesh", foundEmployee.getName());
    }

    @Test
    void testFindByEmpId_NotFound() {
        // Arrange
        when(entityManager.find(Employee.class, 99)).thenReturn(null);

        // Act
        Employee foundEmployee = employeeDAO.findbyempid(99);

        // Assert
        assertNull(foundEmployee);
    }

    @Test
    void testFindAllEmployees() {
        // Arrange
        List<Employee> employees = Arrays.asList(
            new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890"),
            new Employee(2, "priya", "priya@example.com", "2222222222")
        );

        TypedQuery<Employee> query = mock(TypedQuery.class);
        when(entityManager.createQuery("FROM Employee", Employee.class)).thenReturn(query);
        when(query.getResultList()).thenReturn(employees);

        // Act
        List<Employee> foundEmployees = employeeDAO.findAll();

        // Assert
        assertEquals(2, foundEmployees.size());
    }

    @Test
    void testUpdateEmployee() {
        // Arrange
        Employee employee = new Employee(1, "Updated Sarvesh", "updated@example.com", "1112223333");
        when(entityManager.merge(employee)).thenReturn(employee);

        // Act
        Employee updatedEmployee = employeeDAO.update(employee);

        // Assert
        assertNotNull(updatedEmployee);
        assertEquals("Updated Sarvesh", updatedEmployee.getName());
    }

    @Test
    void testDeleteByEmpId() {
        // Arrange
        Employee employee = new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890");
        when(entityManager.find(Employee.class, 1)).thenReturn(employee);

        // Act
        employeeDAO.deleteByempid(1);

        // Assert
        verify(entityManager, times(1)).remove(employee);
    }

    @Test
    void testDeleteByEmpId_NotFound() {
        // Arrange
        when(entityManager.find(Employee.class, 99)).thenReturn(null);

        // Act
        employeeDAO.deleteByempid(99);

        // Assert
        verify(entityManager, never()).remove(any(Employee.class));
    }
}
