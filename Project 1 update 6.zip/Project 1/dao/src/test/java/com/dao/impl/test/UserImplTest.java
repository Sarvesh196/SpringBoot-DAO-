package com.dao.impl.test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dao.entity.User;
import com.dao.impl.UserDAOJpaImpl;

public class UserImplTest {

    @Mock
    private EntityManager entityManager;

    @InjectMocks
    private UserDAOJpaImpl userDAO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveUser() {
        // Arrange
        User user = new User(1, "Sarvesh", "sarvesh@example.com", "password123");

        // Act
        userDAO.save(user);

        // Assert
        verify(entityManager, times(1)).persist(user);
    }

    /*
     * 	@Test
		void testSaveUser() {
    	// Arrange
    	User user = new User(1, "Sarvesh", "sarvesh@example.com", "password123");
		Mockito.when(entityManager.persist(any())).thenReturn(user);
		
    	// Act
    	userDAO.save(user);

    	// Assert
    	verify(entityManager, times(1)).persist(user);
    	assertNotNull(result); // No need to check return value because persist() is void
		}

     * 
     */
    
    @Test
    void testFindById_Found() {
        // Arrange
        User user = new User(1, "Sarvesh", "sarvesh@example.com", "password123");
        when(entityManager.find(User.class, 1)).thenReturn(user);

        // Act
        User foundUser = userDAO.findById(1);

        // Assert
        assertNotNull(foundUser);
        assertEquals("Sarvesh", foundUser.getUsername());
    }

    @Test
    void testFindById_NotFound() {
        // Arrange
        when(entityManager.find(User.class, 99)).thenReturn(null);

        // Act
        User foundUser = userDAO.findById(99);

        // Assert
        assertNull(foundUser);
    }

    @Test
    void testFindAllUsers() {
        // Arrange
        List<User> users = Arrays.asList(
            new User(1, "Sarvesh", "sarvesh@example.com", "password123"),
            new User(2, "priya", "priya@example.com", "pass456")
        );

        TypedQuery<User> query = mock(TypedQuery.class);
        when(entityManager.createQuery("FROM User", User.class)).thenReturn(query);
        when(query.getResultList()).thenReturn(users);

        // Act
        List<User> foundUsers = userDAO.findAll();

        // Assert
        assertEquals(2, foundUsers.size());
    }

    @Test
    void testUpdateUser() {
        // Arrange
        User user = new User(1, "Updated Sarvesh", "updated@example.com", "newpassword");
        when(entityManager.merge(user)).thenReturn(user);

        // Act
        User updatedUser = userDAO.update(user);

        // Assert
        assertNotNull(updatedUser);
        assertEquals("Updated Sarvesh", updatedUser.getUsername());
    }

    @Test
    void testDeleteById_Found() {
        // Arrange
        User user = new User(1, "Sarvesh", "sarvesh@example.com", "password123");
        when(entityManager.find(User.class, 1)).thenReturn(user);

        // Act
        userDAO.deleteById(1);

        // Assert
        verify(entityManager, times(1)).remove(user);
    }

    @Test
    void testDeleteById_NotFound() {
        // Arrange
        when(entityManager.find(User.class, 99)).thenReturn(null);

        // Act
        userDAO.deleteById(99);

        // Assert
        verify(entityManager, never()).remove(any(User.class));
    }
}
