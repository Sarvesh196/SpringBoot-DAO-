package com.dao.repo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.dao.entity.Employee;

@DataJpaTest // Enables JPA-based testing
public class EmployeeRepositoryTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @BeforeEach
    void setUp() {
        employeeRepository.deleteAll(); // Clear previous test data
    }

    @Test
    void testSaveEmployee() {
        // Arrange
        Employee employee = new Employee(1, "John Doe", "john@example.com", "1234567890");

        // Act
        Employee savedEmployee = employeeRepository.save(employee);

        // Assert
        assertNotNull(savedEmployee);
        assertEquals("John Doe", savedEmployee.getName());
    }

    @Test
    void testFindById() {
        // Arrange
        Employee employee = new Employee(0, "Jane Doe", "jane@example.com", "9876543210"); // Let Hibernate assign ID
        Employee savedEmployee = employeeRepository.save(employee);
        employeeRepository.flush(); // Ensures DB transaction commits before retrieval

        // Act
        Optional<Employee> foundEmployee = employeeRepository.findById(savedEmployee.getEmpid());

        // Assert
        assertTrue(foundEmployee.isPresent());
        assertEquals("Jane Doe", foundEmployee.get().getName());
    }


    @Test
    void testFindAllEmployees() {
        // Arrange
        employeeRepository.save(new Employee(4, "John Doe", "john@example.com", "2222222222"));
        employeeRepository.save(new Employee(5, "Jane Doe", "jane@example.com", "3333333333"));

        // Act
        List<Employee> employees = employeeRepository.findAll();

        // Assert
        assertEquals(2, employees.size());
    }

    @Test
    void testDeleteEmployee() {
        // Arrange
        Employee employee = new Employee(6, "Mark Smith", "mark@example.com", "4444444444");
        employeeRepository.save(employee);

        // Act
        employeeRepository.deleteById(6);

        // Assert
        Optional<Employee> deletedEmployee = employeeRepository.findById(6);
        assertFalse(deletedEmployee.isPresent());
    }
}



