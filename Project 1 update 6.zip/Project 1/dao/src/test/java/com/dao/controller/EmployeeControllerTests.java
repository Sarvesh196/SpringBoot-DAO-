package com.dao.controller;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import com.dao.entity.Employee;
import com.dao.service.EmployeeService;

public class EmployeeControllerTests {

    @Mock
    private EmployeeService employeeService;

    @InjectMocks
    private EmployeeController employeeController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateEmployee() {
        // Arrange
        Employee employee = new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890");
        when(employeeService.saveEmployee(any(Employee.class))).thenReturn(employee);

        // Act
        ResponseEntity<Employee> response = employeeController.createEmployee(employee);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Sarvesh", response.getBody().getName());
    }

    @Test
    void testGetEmployeeById_Found() {
        // Arrange
        Employee employee = new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890");
        when(employeeService.getEmployeeById(1)).thenReturn(employee);

        // Act
        ResponseEntity<?> response = employeeController.getEmployeeById(1);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Sarvesh", ((Employee) response.getBody()).getName());
    }

    @Test
    void testGetEmployeeById_NotFound() {
        // Arrange
        when(employeeService.getEmployeeById(99)).thenReturn(null);

        // Act
        ResponseEntity<?> response = employeeController.getEmployeeById(99);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Employee doesn't exist with ID 99", response.getBody());
    }

    @Test
    void testGetAllEmployees() {
        // Arrange
        List<Employee> employees = Arrays.asList(
            new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890"),
            new Employee(2, "priya", "priya@example.com", "2222222222")
        );
        when(employeeService.getAllEmployees()).thenReturn(employees);

        // Act
        ResponseEntity<List<Employee>> response = employeeController.getAllEmployees();

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    void testUpdateEmployee_Success() {
        // Arrange
        Employee existingEmployee = new Employee(1, "Sarvesh", "sarvesh@example.com", "1234567890");
        Employee updatedEmployee = new Employee(1, "Updated Sarvesh", "updated@example.com", "1112223333");
        when(employeeService.getEmployeeById(1)).thenReturn(existingEmployee);
        when(employeeService.updateEmployee(any(Employee.class))).thenReturn(updatedEmployee);

        // Act
        ResponseEntity<?> response = employeeController.updateEmployee(1, updatedEmployee);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Updated Sarvesh", ((Employee) response.getBody()).getName());
    }

    @Test
    void testUpdateEmployee_NotFound() {
        // Arrange
        when(employeeService.getEmployeeById(99)).thenReturn(null);

        // Act
        ResponseEntity<?> response = employeeController.updateEmployee(99, new Employee());

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Employee doesn't exist with ID 99", response.getBody());
    }
    
    @Test
    void testDeleteEmployee() {
        // Arrange
        doNothing().when(employeeService).deleteEmployee(1);

        // Act
        ResponseEntity<String> response = employeeController.deleteEmployee(1);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Employee Deleted Successfully", response.getBody());
    }
}
