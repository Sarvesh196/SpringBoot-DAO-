package com.dao.entity;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserTest {

    private User usr;

    @BeforeEach
    void setUp() {
        usr = new User(1, "Sarvesh", "Pass123", "sarvesh@example.com");
    }

    @Test
    void testGetUserid() {
        assertEquals(1, usr.getUserid());
    }

    @Test
    void testSetUserid() {
        usr.setUserid(2);
        assertEquals(2, usr.getUserid());
    }

    @Test
    void testGetUsername() {
        assertEquals("Sarvesh", usr.getUsername());
    }

    @Test
    void testSetUsername() {
        usr.setUsername("Sarvesh");
        assertEquals("Sarvesh", usr.getUsername());
    }

    @Test
    void testGetPassword() {
        assertEquals("Pass123", usr.getPassword());
    }

    @Test
    void testSetPassword() {
        usr.setPassword("NewPass456");
        assertEquals("NewPass456", usr.getPassword());
    }

    @Test
    void testGetEmail() {
        assertEquals("sarvesh@example.com", usr.getEmail());
    }

    @Test
    void testSetEmail() {
        usr.setEmail("sarvesh@example.com");
        assertEquals("sarvesh@example.com", usr.getEmail());
    }

    @Test
    void testToString() {
        String expectedString = "user [userid=1, username=Sarvesh, password=Pass123, email=sarvesh@example.com]";
        assertEquals(expectedString, usr.toString());
    }
}
