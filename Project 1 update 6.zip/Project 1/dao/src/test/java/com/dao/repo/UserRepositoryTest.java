package com.dao.repo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.dao.entity.User;

import jakarta.transaction.Transactional;

@Transactional
@DataJpaTest // Enables JPA-related testing with H2 in-memory database
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void setUp() {
        userRepository.deleteAll(); // Clear previous test data
    }

    
    @Test
    void testSaveUser() {
        // Arrange
        User user = new User(1, "admin", "admin123", "admin@email.com");

        // Act
        User savedUser = userRepository.save(user);
        userRepository.flush();
        
        // Assert
        assertNotNull(savedUser);
        assertNotNull(savedUser.getUserid()); 
        assertEquals("admin", savedUser.getUsername());
    }

    @Test
    void testFindById() {
        // Arrange
        User user = new User(0, "testuser", "password", "testuser@email.com");
        User savedUser = userRepository.save(user);
        userRepository.flush();

        // Act
        
        Optional<User> foundUser = userRepository.findById(savedUser.getUserid());

        // Assert
        assertTrue(foundUser.isPresent());
        assertEquals("testuser", foundUser.get().getUsername());
    }

    @Test
    void testFindAllUsers() {
        // Arrange
        userRepository.save(new User(4, "JohnDoe", "pass123", "john@example.com"));
        userRepository.save(new User(5, "JaneDoe", "pass456", "jane@example.com"));
        userRepository.flush();

        // Act
        List<User> users = userRepository.findAll();

        // Assert
        assertEquals(2, users.size());
    }

    @Test
    void testDeleteUser() {
        // Arrange
        User user = new User(6, "Mark", "mark123", "mark@email.com");
        User savedUser = userRepository.save(user);

        // Act
        userRepository.deleteById(savedUser.getUserid());

        // Assert
        Optional<User> deletedUser = userRepository.findById(6);
        assertFalse(deletedUser.isPresent());
    }
}
