package com.dao.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EmployeeTests {
	 private Employee emp;

	    @BeforeEach
	    void setUp() {
	        emp = new Employee(1, "Sarvesh", "sarvesh@gmail.com", "1234567890");
	    }

	    @Test
	    void testGetEmpid() {
	        assertEquals(1, emp.getEmpid());
	    }

	    @Test
	    void testSetEmpid() {
	    	//ASSIGNMENT
	    	
	    	//ACTION
	    	
	    	//ASSERT
	        emp.setEmpid(2);
	        assertEquals(2, emp.getEmpid());
	    }

	    @Test
	    void testGetName() {
	        assertEquals("Sarvesh", emp.getName());
	    }

	    @Test
	    void testSetName() {
	        emp.setName("Sarvesh");
	        assertEquals("Sarvesh", emp.getName());
	    }

	    @Test
	    void testGetEmail() {
	        assertEquals("sarvesh@gmail.com", emp.getEmail());
	    }

	    @Test
	    void testSetEmail() {
	        emp.setEmail("sarvesh@gmail.com");
	        assertEquals("sarvesh@gmail.com", emp.getEmail());
	    }

	    @Test
	    void testGetPhno() {
	        assertEquals("1234567890", emp.getPhno());
	    }

	    @Test
	    void testSetPhno() {
	        emp.setPhno("0987654321");
	        assertEquals("0987654321", emp.getPhno());
	    }

	    @Test
	    void testToString() {
	        String expectedString = "employee [empid=1, name=Sarvesh, email=sarvesh@gmail.com, phno=1234567890]";
	        assertEquals(expectedString, emp.toString());
	    }
	}
