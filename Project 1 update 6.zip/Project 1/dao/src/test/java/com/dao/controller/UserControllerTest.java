package com.dao.controller;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import com.dao.entity.User;
import com.dao.service.UserService;

public class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateUser() {
        // **Arrange**
        User user = new User(1, "Sarvesh", "sarvesh@example.com", "password123");
        when(userService.saveUser(any(User.class))).thenReturn(user);

        // **Act**
        ResponseEntity<User> response = userController.createUser(user);

        // **Assert**
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Sarvesh", response.getBody().getUsername());
    }

    @Test
    void testGetUserById_Found() {
        // **Arrange**
        User user = new User(1, "Sarvesh", "sarvesh@example.com", "password123");
        when(userService.getUserById(1)).thenReturn(user);

        // **Act**
        ResponseEntity<?> response = userController.getUserById(1);

        // **Assert**
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Sarvesh", ((User) response.getBody()).getUsername());
    }

    @Test
    void testGetUserById_NotFound() {
        // Arrange
        when(userService.getUserById(99)).thenReturn(null);

        // Act
        ResponseEntity<?> response = userController.getUserById(99);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("User doesn't exist with ID 99", response.getBody());
    }

    @Test
    void testGetAllUsers() {
        // **Arrange**
        List<User> users = Arrays.asList(
            new User(1, "Sarvesh", "sarvesh@example.com", "password123"),
            new User(2, "JohnDoe", "john@example.com", "pass456")
        );
        when(userService.getAllUsers()).thenReturn(users);

        // **Act**
        ResponseEntity<List<User>> response = userController.getAllUsers();

        // **Assert**
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    void testUpdateUser_Success() {
        // **Arrange**
        User existingUser = new User(1, "Sarvesh", "sarvesh@example.com", "password123");
        User updatedUser = new User(1, "Updated Sarvesh", "updated@example.com", "newpassword");
        when(userService.getUserById(1)).thenReturn(existingUser);
        when(userService.updateUser(any(User.class))).thenReturn(updatedUser);

        // **Act**
        ResponseEntity<?> response = userController.updateUser(1, updatedUser);

        // **Assert**
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Updated Sarvesh", ((User) response.getBody()).getUsername());
    }

    @Test
    void testUpdateUser_NotFound() {
        // **Arrange**
        when(userService.getUserById(99)).thenReturn(null);

        // **Act**
        ResponseEntity<?> response = userController.updateUser(99, new User());

        // **Assert**
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("User doesn't exist with ID 99", response.getBody());
    }

    @Test
    void testDeleteUser() {
        // **Arrange**
        doNothing().when(userService).deleteUser(1);

        // **Act**
        ResponseEntity<String> response = userController.deleteUser(1);

        // **Assert**
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("User Deleted Successfully", response.getBody());
    }
}
