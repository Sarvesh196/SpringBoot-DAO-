package com.api;

public class demo {
	public static void main(String[]args) {
		System.out.println("Hey API Module is Running");
	}
	

}
